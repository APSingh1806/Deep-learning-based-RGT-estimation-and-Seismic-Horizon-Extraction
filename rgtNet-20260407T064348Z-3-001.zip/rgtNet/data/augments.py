import numpy as np
import torch

class Reshape(object):
    """Reshape the data to a given size."""
    def __init__(self, output_size):
        assert isinstance(output_size, tuple)
        self.output_size = output_size

    def __call__(self, data):
        data = np.reshape(data, self.output_size)
        return data

class CropVolume(object):
    """Crop centre of volume to target shape."""
    def __init__(self, crop_size):
        assert isinstance(crop_size, tuple)
        self.crop_size = crop_size  # (n1, n2, n3, n_channels)

    def __call__(self, data):
        # data shape after Reshape: (n1, n2, n3, n_channels)
        n1, n2, n3, nc = data.shape
        c1, c2, c3, _  = self.crop_size

        # Crop centre
        s1 = (n1 - c1) // 2
        s2 = (n2 - c2) // 2
        s3 = (n3 - c3) // 2

        return data[s1:s1+c1, s2:s2+c2, s3:s3+c3, :]

class ToTensor(object):
    """Convert ndarrys in sample to Tensors"""
    def __call__(self, data):
        data = data.transpose((3, 2, 1, 0))
        return data

def VerticalFlip(dat):
    return torch.flip(dat, dims=[2])

def VerticalFlip_reverse(dat):
    return -torch.flip(dat, dims=[2])

def HorizontalFlip1(dat):
    return torch.flip(dat, dims=[3])

def HorizontalFlip2(dat):
    return torch.flip(dat, dims=[4])
